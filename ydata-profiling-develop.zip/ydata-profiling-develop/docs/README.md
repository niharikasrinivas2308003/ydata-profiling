# YData Profiling Documentation

Installing the documentation dependencies (one time step):
```bash
make install-docs
```

Build the doc for deployment:
```
mkdocs build
```

To build and serve locally:
```
mkdocs serve
```
